<div class="limiter">
    <div class="container-login100">

        <div class="wrap-login100 p-l-50 p-r-50 p-t-30 p-b-30">
            <div class="top_cssdiv"> <div class="left_div"><a href="<?php echo base_url() ?>frontend/signupar/<?php echo $this->uri->segment(3);?>/<?php echo $this->uri->segment(4);?>"> الرئيسية</a> </div><div class="right_div"> <a href="<?php echo base_url() ?>frontend/signup/<?php echo $this->uri->segment(3);?>/<?php echo $this->uri->segment(4);?>" class="lang_menu mob_lan"> <i class="fa fa-globe" aria-hidden="true"></i> English </a> </div> </div>
            <div class="text-center">
                <!--<img src="images/logo.jpg" class="logo_350">-->
                <img src="<?php echo base_url() ?>skin/admin2.3/frontend/images/logo.jpg" class="logo_350">
            </div>
            <br>
            <span class="login100-form-title p-b-30">
						<span class="text_login">استبيان العملاء</span>
						<span class="bor_login"></span>
					</span>

            <br>	<br>
            <div>
                <svg class="checkmarkc" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 52 52"><circle class="checkmark__circle" cx="26" cy="26" r="25" fill="none"/><path class="checkmark__check" fill="none" d="M14.1 27.2l7.1 7.2 16.7-16.8"/></svg>
            </div>
            <div class="text-center">
                <h2>لقد أكملت الاستبيان بنجاح</h2>
            </div>
            <br>
        </div>
        <div class="text-center " style="display: block;width: 100%;position: relative;">
            <p class="text-center  mb-md-0" style="color: #333;">حقوق النشر 2021 . دانكن . جميع الحقوق محفوظة</p>
        </div>
    </div>

</div>

	
