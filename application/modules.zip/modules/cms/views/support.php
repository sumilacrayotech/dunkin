<div id="content" class="clearfix">
            <div class="contentwrapper"><!--Content wrapper-->
                <div class="heading">
                    <h3>Manage Support</h3>                     
                </div><!-- End .heading-->
                <!-- Build page from here: -->
                <div class="row-fluid">
                <?php echo $output; ?>
                </div><!-- End .row-fluid -->
                <!--End page -->
            </div><!-- End contentwrapper -->
        </div>